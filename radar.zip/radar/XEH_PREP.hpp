

PREP(deployRadarEast);
PREP(deployRadarWest);
PREP(runRadarWest);
PREP(runRadarEast);
PREP(undeployRadarEast);
PREP(undeployRadarWest);
PREP(postInit);