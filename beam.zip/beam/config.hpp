#include "script_component.hpp"

#include "config\dialog.hpp"
