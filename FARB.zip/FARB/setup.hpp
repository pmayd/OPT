#define STR_FARB_DEPLOY "FARB aufbauen"
#define STR_FARB_UNDEPLOY "FARB abbauen"

